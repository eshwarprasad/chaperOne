import os
import time

print("starting...")

while True:
	time.sleep(2)
	os.system("python3 yolo.py")
